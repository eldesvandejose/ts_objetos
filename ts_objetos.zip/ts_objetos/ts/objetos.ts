let miVehiculo: {
    ruedas:number, 
    motor:number, 
    color:string,
    deposito:number,
    autonomia:number,
    automatico:boolean
} = {
    ruedas: 4, 
    motor: 1600, 
    deposito: 100,
    autonomia: 1500, 
    automatico: true, 
    color: "verde"
}

console.log(miVehiculo);

miVehiculo.color = "rojo";


